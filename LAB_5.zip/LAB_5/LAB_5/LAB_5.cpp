#include<iostream>
using namespace std;

const int ROW_SIZE = 4; 
const int COLUMN_SIZE = 3; 
int row, column;

//line 1
void display (const int array2 [ROW_SIZE][COLUMN_SIZE])
{
	cout << "Display all elements of the array." <<endl;
	for(row = 0; row < ROW_SIZE; row++)

	{
		for(column = 0; column < COLUMN_SIZE; column++)
		
		{
			cout << array2 [row][column] <<endl;
		}
	}
}

//line 2
int sum (const int array1 [ROW_SIZE][COLUMN_SIZE])
{
	int total = 0;
	for(row = 0; row < ROW_SIZE; row++)
	{
		for(column = 0; column < COLUMN_SIZE; column++)
		{
			total += array1 [row][column];
		}
	}
	return total;
}


int main()
{
	int array[ROW_SIZE][COLUMN_SIZE];
	cout <<"Asking user to enter values of arrays elements."; 
	cout << endl;
	
	for (row = 0; row < ROW_SIZE; row++)
	{
		for (column = 0; column < COLUMN_SIZE; column++)
		{
			cout <<"Please enter an integer for array of "; 
			cout <<"row " <<row <<" and column " <<column; 
			cout <<" : ";
			cin >> array[row][column]; 
			cout << endl;
		}
	}
	
	cout << endl;
	
	//line 3
	cout << "Calling function of display." <<endl; 
	display (array);

	//line 4
	cout << "Sum of all elements is " << sum (array) <<endl;

	return 0;
}

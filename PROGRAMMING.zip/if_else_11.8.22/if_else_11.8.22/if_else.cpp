// (11/8/22)
// if else
// DKI_3A
// 

#include <iostream>
using namespace std;

int main()

{
	float budget = 1.00;
	float apple = 2.00;
	float orange = 3.50;
	float balance;

	if (budget>apple)
	{
		balance = budget - apple;
		if (balance>orange)
		{
			balance = balance - orange;
			cout<<"Thank you for purchasing our product"<<endl;
		}
		else
			cout<<"Can not proceed with another purchase"<<endl;
	}

	else 
		cout<<"Not enough money!!"<<endl;


		return 0;
}



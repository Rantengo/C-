// 22/9/22
// CH5.c
// 

#include <iostream>
#include <fstream>
using namespace std;

int main ()
{
	ifstream input;

	input.open ("text.txt");

	if (input.fail ())
	{
		cout<<"Fail tidak wujud"<<endl;
		cout<<"Hentikan program"<<endl;

		return 0;
	}

	char firstName [100];
	char secondName [100];
	int score;

	while (!input.eof())
	{
		input >> firstName >> secondName >> score;
		cout << firstName << " " << secondName <<  " " << score << endl;
	}

	input.close();
	cout << "SELESAI" <<endl;

	return 0;
}
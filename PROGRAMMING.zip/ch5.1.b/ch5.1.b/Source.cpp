//ch5.1.b
//(1/9/22)
//
//

#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	ifstream input;

	input.open("latihan 5.1.b");

	char Name [90];
	char Score;

	input >> Name >> Score;
	cout << Name <<" "<< Score;

	input >> Name >> Score;
	cout << Name << " " << Score;

	input >> Name >> Score;
	cout << Name << " " << Score;

	input.close();

	cout << "COMPETLED" << endl;

	return 0;
}

// switch
// 11/8/22
// 
// 

#include <iostream>
using namespace std;

int main ()
{ 
	int color;
	cout<<"Pick your weapon: "<<endl;
	cout<<"SCAR=1"<<endl;
	cout<<"M4A1=2"<<endl;
	cout<<"M110=3"<<endl;
	cout<<"MK46=4"<<endl;
	cout<<"M320=5"<<endl;
	cout<<"M17=6"<<endl;
	cout<<"M60E3=7"<<endl;
	cout<<"AX338=8"<<endl;
	cin>>color;

	switch (color)
	{
	case 0:
		{
			cout<<"G19X"<<endl;
			cout<<endl;
			break;
		}
	cout<<endl;
		case 1:
		{
			cout<<"M4A1"<<endl;
			cout<<endl;
			break;
		}
cout<<endl;
		case 2:
		{
			cout<<"M110"<<endl;
			cout<<endl;
			break;
		}
cout<<endl;
		case 3:
		{
			cout<<"MK46"<<endl;
			cout<<endl;
			break;
		}
cout<<endl;
		case 4:
		{
			cout<<"M320"<<endl;
			cout<<endl;
			break;
		}
cout<<endl;
		case 5:
		{
			cout<<"M17"<<endl;
			cout<<endl;
			break;
		}
cout<<endl;
		case 6:
		{
			cout<<"M60E3"<<endl;
			cout<<endl;
			break;
		}
cout<<endl;
		case 7:
		{
			cout<<"AX338"<<endl;
			cout<<endl;
			break;
		}
cout<<endl;
		case 8:
		{
			cout<<"AX338"<<endl;
			cout<<endl;
			break;
		}
cout<<endl;
		default:
			{
				cout<<"!!!!!WARNING!!!!!"<<endl;
				cout<<"INTRUDER WILL BE EXECUTED!!!!!"<<endl;
				cout<<".....LOCKDOWN INITIATED....."<<endl;
				break;
			}
	}
	return 0;
}
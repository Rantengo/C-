//
//

#include <iostream>
#include <fstream>
using namespace std;

int main ()
{
	ifstream input;

	input.open ("sini.txt");
	if (input.fail())
	{
		cout<<"File not exist"<<endl;
		cout<<"End program"<<endl;

		return 0;
	}

	char city [50];

	while (!input.eof())
	{
		input.getline(city, 40, "#");
		cout<<bandar<<endl;
	}
		input.close();
		cout<<"Settle"<<endl;
		return 0;
	}
// tutorial CH4

#include <iostream>
#include<iomanip>
#include<fstream>
using namespace std;
int main()
{
	ofstream output;
	//Create a file
	output.open("FILLES.txt");
	//Write two lines
	output << setw(7) << "Muhd" << " " << setw(9) << "Abdullah" << " " << setw(5) << 66 << endl;
	output << setw(7) <<"Mohamad" << " " << setw(9) <<"Harun" << " " << setw(5) << 77 << endl;
	output << setw(7) <<"Nik" << " " << setw(9) <<"Azila" << " " << setw(5) << 88 << endl;

	output.close();
	cout << "Done" <<endl;
	
	return 0;
}

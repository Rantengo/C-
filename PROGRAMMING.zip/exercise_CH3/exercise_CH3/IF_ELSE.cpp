//MUHAMMAD ALIFF HAIKAL
//[IF/ELSE](4/8/22)
//DKI-3A

#include <iostream>
using namespace std;

int main()
{
	int X, Y, Z;
	cout << "ENTER 1st VALUE: " << endl;
	cin >> X;
	cout << endl;

	cout << "ENTER 2nd VALUE: " << endl;
	cin >> Y;
	cout << endl;

	cout << "ENTER 3rd VALUE: " << endl;
	cin >> Z;
	cout << endl;


	if (X>Y)
	{
		cout << "TRUE" << endl;
		cout << X + Y + Z << endl;
	}
	else
	{
		cout << "FALSE" << endl;
		cout << Y- X << endl;
	}

	if (Z < X)
	{
		cout << "TRUE " << endl;
		cout << X - Z << endl;
	}
	else
	{
		cout << "FALSE" << endl;
	}

	return 0;


}
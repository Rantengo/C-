//Pass by value
//
//
//

#include <iostream>
#include <string>
using namespace std;

void printNAME (string NAME1,int AGE1);

int main ()
{
	string NAME2;
	int AGE2;

	cout<<"Name: "<<endl;
	cin>>NAME2;

	cout<<"Age: "<<endl;
	cin>>AGE2;

	printNAME (NAME2,AGE2);

	return 0;
}

void printNAME (string NAME1,int AGE1)
{
	cout<<"Your name is "<<NAME1<<" and your age is "<<AGE1<<endl;
}

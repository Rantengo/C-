//
//

#include <iostream>
using namespace std;

int max(int first,int second);
double max(double first,double second);
double max(double first,double second,double third);

int main ()
{
	cout<<"max value "<<max(4,5)<<endl;
	cout<<"maximum "<<max(3.3,6.6)<<endl;
	cout<<"peak result "<<max (2.2,1.1,7.7)<<endl;

	return 0;
}

int max(int first,int second)
{
	if (first>second)
		return first;
	else
		return second;
}

double max(double first,double second)
{
	if (first>second)
		return first;
	else
		return second;
}

double max(double first,double second,double third)
{
	return max(max(first,second),third);
}

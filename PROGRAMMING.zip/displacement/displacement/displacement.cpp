// (28/7/22)
// DKI-3A
// MUHAMMAD ALIFF HAIKAL

#include <iostream>
using namespace std;

int main ()

{
	float Dball = 16;
	float Dcyl = 20;
	float Hcyl = 30;
	float Pi = 4.132;

	//formula volume
	float Vball = (4/3)*Pi*(Dball*Dball*Dball/8);
	float Vcyl = Pi*Hcyl*(Dcyl*Dcyl/4);

	//baki air
	float leftover = Vcyl - Vball;

	//output
	cout<<"Diameter bola: "<<Dball<<endl;
	cout<<endl;
	cout<<"Diameter silinder: "<<Dcyl<<endl;
	cout<<endl;
	cout<<"Tinggi silinder: "<<Hcyl<<endl;
	cout<<endl;
	cout<<"Baki air dalam silinder: "<<leftover<<endl;
	cout<<endl;

	return 0;
}
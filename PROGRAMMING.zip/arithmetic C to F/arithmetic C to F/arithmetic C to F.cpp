// (28/7/22)
// DKI-3A
// MUHAMMAD ALIFF HAIKAL 


#include <iostream>
using namespace std;
int main()

{
	double fahrenheit;
	// input FAHRENHEIT
	cout <<"enter Fahrenheit";
	cout << endl;
	cin >> fahrenheit;
	cout<<endl;

	// formula CELCIUS
	double celcius = (5.0/9)*(fahrenheit-32);

	// output
	cout<< endl;
	cout<< "Fahrenheit" << fahrenheit << "is" 
		<< celcius << "in Celsius" << endl;
	cout <<endl;

	// pesan2
	cout<< "kire sendiri la\n";
	cout<< "pemalas\n";
	cout<< "beban keluarga\n";

	return 0;
}
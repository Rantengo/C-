//  21/7/22
//  DKI 3A (2022)
//  MUHAMMAD ALIFF HAIKAL BIN ZAIDI
//  example 2.1

#include <iostream>
using namespace std;

int main ()
{
	const float Pi = 3.142;
	int radius ;
	double area;
	
	cout <<"enter radius = ";
    cin >>radius;
	area = radius *radius* Pi;

    
	cout <<"The Pi is "<< Pi << endl;
	cout <<"The area is "<< area << endl;
cout <<endl;
	cout << "banyak lak songeh" << endl;
cout << "pijak kang" << endl;
	return 0;
}
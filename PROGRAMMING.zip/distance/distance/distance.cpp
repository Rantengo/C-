//(28/7/22)
//DKI-3A
//MUHAMMAD ALIFF HAIKAL

#include <iostream>
using namespace std;

int main ()

{
	float CAR = 63;
	float BUS = 54;
	float time;

	//formula jarak
	float dCAR = time*CAR;
	float dBUS = time*BUS;

	cout<<"enter the time in HOUR: ";
	cin>>time;

	//output
	cout<<"Jarak kereta: "<<dCAR<<endl;
	cout<<endl;
	cout<<"Jarak bas: "<<dBUS<<endl;
	cout<<endl;
	


	return 0;
}



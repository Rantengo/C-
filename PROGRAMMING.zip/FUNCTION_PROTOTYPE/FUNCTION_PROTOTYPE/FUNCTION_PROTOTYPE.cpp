//function prototype
//DKI-3A
//MUHAMMAD ALIFF HAIKAL
//25/8/22

#include <iostream>
using namespace std;

void ALIFF (int);

int main ()
{
	int marks;
	cout<<"Enter your marks mate: "<<endl;
	cin>>marks;

	ALIFF (marks);

	return 0;
}

void ALIFF (int grade)
{
	cout<<"Your marks is = "<<grade<<endl;
	cout<<"No dozing. "<<endl;
	cout<<"Let's have a proper pint "<<endl;
}
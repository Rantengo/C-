//ch5.a.1
//(1/9/22)
//MUHAMMAD ALIFF HAIKAL
//DKI-3A

#include <iostream>
#include <fstream>
using namespace std;

int main()
{
	ofstream output;

	output.open("score.txt");

	output<<"Hassan "<<""<<"Fareeq: "<<""<<80<<endl;
	output<<"Izzul "<<""<<"Farhan: "<<""<<70<<endl;
	output<<"Aliff "<<""<<"Haikal: "<<""<<90<<endl;

	output.close();

	cout<<"COMPLETED"<<endl;

	return 0;
}

//
//loop
//DKI-3A
//

#include <iostream>
using namespace std;

int main ()
{
	int num = 1;
	int count = 0;
	do
	{
		cout<<num<<endl;
		num = num + 2;
		count=count+1;
	}
	while (count<6);

	return 0;
}

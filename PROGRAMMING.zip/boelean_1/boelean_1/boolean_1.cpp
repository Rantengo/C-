//(4/8/22)
// DKI-3A
// MUHAMMAD ALIFF HAIKAL

#include <iostream>
using namespace std;

int main ()

{
	int A,B;

	cout<<"Enter the 1st value: ";
	cin>>A;
	cout<<endl;

	cout<<"Enter the 2nd value: ";
	cin>>B;
	cout<<endl;

	bool compare = (A==B);
	cout<<"Result: "<<compare<<endl;

	return 0;
}


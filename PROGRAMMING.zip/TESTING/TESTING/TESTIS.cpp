// MUHAMMAD ALIFF HAIKAL BIN ZAIDI
// DKI 3A (2022)
// 2115720
// 14/7/22

#include <iostream> 
using namespace std;

int main ()
{
	cout<< "yemete kudasai" <<endl;
	cout<< "ara ara" <<endl ;
	cout<< " miau miau nigga\n ";
	cout<< " wanker " <<endl ;

return 0;
}

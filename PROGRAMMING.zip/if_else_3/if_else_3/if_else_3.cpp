//(11/8/22)
// if else
// DKI_3A
// MUHAMMAD ALIFF HAIKAL

#include <iostream>
using namespace std;

int main ()
{
	int book;
	cout<<"Enter the value: "<<endl;
	cin>>book;

	if (book==1)
	{
		cout<<"1 book"<<endl;
	}
	else if (book==2)
	{
		cout<<"2 book"<<endl;
	}
	else if (book==3)
	{
		cout<<"3 book"<<endl;
	}
	else
	{
		cout<<"NO MATCH"<<endl;
	}


	return 0;
}
//DKI-3A
//MUHAMMAD ALIFF HAIKAL
//(if/else)[4/8/22]

#include <iostream>
using namespace std;

int main ()

{
int X, Y;
	cout << "ENTER 1st VALUE: " << endl;
	cin >> X;
	cout << endl;

	cout << "ENTER 2nd VALUE: " << endl;
	cin >> Y;
	cout << endl;


	if (X == Y)
	{
		cout << "TRUE" << endl;
		cout << X + Y << endl;
	}
	else
	{
		cout << "FALSE" << endl;
		cout << X - Y << endl;
	}

	return 0;

}
// ch6
// 8/11/22
// 

#include<iostream>
using namespace std;
int main()
{
	// declare array
	const int size = 12;
	int myList [size];

	// value for array
	myList [0] = 22;
	myList [1] = 11;
	myList [2] = 8;
	myList [3] = 7;
	myList [4] = 6;

	//display
	cout << myList [0] << endl;
	cout << myList [1] << endl;
	cout << myList [2] << endl;
	cout << myList [3] << endl;
	cout << myList [4] << endl;

	//to display output using for command
	for (int i = 0; i <= 4; i++)
	{
		cout << myList [i] << endl;

	}

	int i =0;
	while (i <= 4)
	{
		cout << myList[i] << endl;
		i++;
	}

	return 0;
}
	

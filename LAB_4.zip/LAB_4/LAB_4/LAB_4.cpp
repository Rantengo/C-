// LAB 4

#include <iostream>
#include<iomanip>
#include<fstream>
using namespace std;
int main()
{
	ofstream out2file;
	//Create a files
	ifstream INfromFile;
	INfromFile.open("Bus_Fees.txt");
	//You must first test here for the file existance
	if ( INfromFile.fail() )
	{ 
		cout << "File does not exist." << endl;
		cout << "Exit program." << endl;
		return 0;
	}

	//Read data
	char City1[80];
	char City2[80];
	float Fees;

	while(!INfromFile.eof()) //continue if not end of file
	{
		INfromFile >> City1 >> City2 >> Fees;
		cout << City1 << " " << City2 << " " << Fees << endl;
	}

	INfromFile.close();

	cout << "Done" << endl;
	return 0;
}
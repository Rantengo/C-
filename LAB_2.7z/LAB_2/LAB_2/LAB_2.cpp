//LAB.2A
//8/9/22
//

#include <iostream>
using namespace std;

int main()
{
	float Val = 1;
	cout << "Enter a value: " << endl;
	cin >> Val;

	if (Val < 0)
	{
		cout << "Old value: " << Val << endl;
		Val = Val + 3;
		cout << "New value: " << Val << endl;
	}

	if (Val > 0)
	{
		cout << "Old value: " << Val << endl;
		Val = Val - 3;
		cout << "New value: " << Val << endl;
	}

	if (Val == 0)
	{
		cout << "Old value: " << Val << endl;
		Val = Val + 2;
		cout << "New value: " << Val << endl;
	}

	return 0;
}






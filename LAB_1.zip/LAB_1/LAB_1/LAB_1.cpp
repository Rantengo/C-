// MUHAMMAD ALIFF HAIKAL
// LAB 1
// 18/8/22

#include <iostream>
#include <iomanip>
using namespace std;
const float pi = 3.14159;
int main ()
{
	
	float inVal = 1;
	cout << "Enter a numeric value: ";
	cin >> inVal;

	cout << fixed;
	cout << showpoint;
	cout << setprecision (2);

	//Area of square
	float sqArea = inVal * inVal; 
	cout << "The area of a square with sides = " 
	<< inVal << " is " << sqArea << endl; 

	//Area of circle
	float circleArea = pi * inVal * inVal; 
    cout << "The area of a circle with radius= " << inVal << " is " << circleArea << endl; 

	//Volume of cube
	float cubeVol = inVal * inVal * inVal;
	cout << "The volume of a cube with sides= " << inVal << " is " << cubeVol << endl;

	//Volume of sphere
	float sphereVol = 4 * pi * inVal * inVal * inVal / 3;
	cout << "The volume of a sphere with radius= " << inVal << " is " << sphereVol << endl;

	//Area of triangle
	float eqTriArea = (1.7321/4) * inVal * inVal;
	cout << "The area of a triangle with side= " << inVal << " is " << eqTriArea << endl;

	return 0;

}